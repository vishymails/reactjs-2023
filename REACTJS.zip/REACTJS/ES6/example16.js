function templateFunction(name, type) {
    return `Company Name : ${name} of type : ${type} 
    From Bangalore `
}


console.log(templateFunction('ISRO', 'Public Ltd'));


