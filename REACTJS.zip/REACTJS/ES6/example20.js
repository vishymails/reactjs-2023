function printBasicInfo({firstName, secondName, profession }){
    console.log(firstName + ' '+ secondName + ' '+ profession);
}

var person = {
    firstName : "Sushanth",
    secondName : "V Rao", 
    age : 10,
    address : "Bangalore",
    profession : "Student"
}


printBasicInfo(person);


