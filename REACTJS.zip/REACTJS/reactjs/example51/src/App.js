import { MyComponent } from "./demo";



function App() {
  return (
    <div>
    <MyComponent />
      
    </div>
  );
}

export default App;
