import React from 'react'

const About = () => {
    return (
        <div>
            <div className="container">
                <h4 className="center">About </h4>
                <p>Sure, you can probably find a peach at the grocery store year-round. But it’s probably not very good—it
                     lacks flavor, is likely a little mealy, and certainly not juicy. Grab a sweet
                     Georgia peach when they’re in season during June and your life will change for the better,
                      bite by bite.</p>
            </div>
        </div>
    )
}

export default About;