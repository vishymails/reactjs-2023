import React from 'react'

const Home = () => {
    return (
        <div>
            <div className="container">
                <h4 className="center">Home </h4>
                <p>Simple Summer Peach Cake

                Summer recipes should be low effort, quick to prepare, and highlight some of the season’s 
                 best produce. This unfussy cake packed with juicy stone fruit certainly fits the bill.    
                </p>   
        </div>
        </div>
    )
}

export default Home;