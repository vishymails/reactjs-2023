import React from 'react'

const Contact = () => {
    return (
        <div>
            <div className="container">
                <h4 className="center">Contact </h4>
                <p>Instead of topping juicy peaches with biscuits or a brown sugar crumble, the 
                    fruit is encased with a moist cake batter. I’m not complaining, are you?</p>
            </div>
        </div>
    )
}

export default Contact;