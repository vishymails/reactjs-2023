import { MyComponent, MyContextProvider } from "./demo";



function App() {
  return (
    <MyContextProvider>
    <div className="App">
    <MyComponent />
      
    </div>
    </MyContextProvider>
  );
}

export default App;
