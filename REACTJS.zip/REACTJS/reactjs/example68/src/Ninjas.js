import React, { Component } from 'react';

class Ninjas extends Component {
    render() {
        return (
            <div className="ninja">
                <div> Name : Ram </div>
                <div> Age : 30</div>
                <div> Belt : Black </div>   
             </div>
        )
    }
}

export default Ninjas;