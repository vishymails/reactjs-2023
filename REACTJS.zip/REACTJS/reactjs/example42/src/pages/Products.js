const Products = () => {
    return <h1> The Product Page </h1>;
};

export default Products;