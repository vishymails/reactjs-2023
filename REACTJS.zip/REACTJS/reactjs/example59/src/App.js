import { FetchData } from "./demo";



function App() {
  return (
    <div className="App">
      <FetchData />
    </div>
   );
}

export default App;
