var fs = require('fs')

fs.rename('myfile1.txt', 'myfile11.txt', function(err) {
    if(err) throw err;
    console.log('file Renamed');
});