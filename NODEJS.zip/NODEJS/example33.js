var events = require('events');

var em = new events.EventEmitter();

em.on('FirstEvent', function(data) {
    console.log('First Subscriber : ' + data);
});

em.emit('FirstEvent', "This is my first event emitter sample");