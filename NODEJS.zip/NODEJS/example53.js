var users = {
    foo : {
        username : 'foo',
        password : 'bar',
        id : 1
    },
    bar : {
        username : 'bar',
        password : 'foo',
        id : 2
    }

}

var Passport = require('passport');

var LocalStrategy = require('passport-local').Strategy;

var localStrategy = new LocalStrategy({
    usernameField : 'username',
    passwordField : 'password'
},
function(username, password, done) {
    user = users[username];

    if(user == null) {
        return done(null, false, {message : 'Invalid User '});
    }

    if(user.password !== password) {
        return done(null, false, {message : 'Invalid Password '});

    }
    done(null, user);
})

Passport.use('local', localStrategy);

var Express = require('express');

var app = Express();

var bodyParser= require('body-parser');

app.use(bodyParser.urlencoded({ extended : false }));

app.use(bodyParser.json());

app.use(Passport.initialize());


app.post( '/login',
    Passport.authenticate('local', {session : false}),
    function(request, response) {
        response.send('User Id ' + request.user.id);
});

app.listen(8080, function () {
    console.log("server started -8080")
})