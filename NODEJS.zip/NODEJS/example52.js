var express = require("express"),
    app = module.exports = express();


app.use(express.basicAuth("admin", "password"));

app.get('/', function(req, res) {
    res.send("Authentication Successful");
});

if(!module.parent) {
    app.listen(3000);
    console.log("server started ");
}

// change express version to 3.21.2