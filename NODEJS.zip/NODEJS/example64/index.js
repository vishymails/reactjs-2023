import { UrlBuilder } from "./urlBuilder.js";

const url = new UrlBuilder()
    .setProtocol('https')
    .setAuthentication('user', 'pass')
    .setHostname('oracle.com')
    .build();


console.log(url.toString());
