require('./patcher')
const logger = require('./logger')

logger.customMessage();
logger.log("message 1");