var fs = require('fs');

var readerStream = fs.createReadStream('myfile11.txt');

var writeStream = fs.createWriteStream('output.txt')

readerStream.pipe(writeStream);

console.log("ended");