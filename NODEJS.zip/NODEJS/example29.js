var fs = require('fs');
var zlib = require('zlib');

fs.createReadStream('example1.htm')
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream('example1.htm.gz'));

console.log("compressed");
