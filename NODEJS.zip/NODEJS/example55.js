var users = {
    foo : {
        username : 'foo',
        password : 'bar',
        id : 1
    },
    bar : {
        username : 'bar',
        password : 'foo',
        id : 2
    }

}

var Passport = require('passport');

var LocalStrategy = require('passport-local').Strategy;

var localStrategy = new LocalStrategy({
    usernameField : 'username',
    passwordField : 'password'
},
function(username, password, done) {
    user = users[username];

    if(user == null) {
        return done(null, false, {message : 'Invalid User '});
    }

    if(user.password !== password) {
        return done(null, false, {message : 'Invalid Password '});

    }
    done(null, user);
})

Passport.use('local', localStrategy);

var Express = require('express');

var app = Express();

var bodyParser= require('body-parser');

app.use(bodyParser.urlencoded({ extended : false }));

app.use(bodyParser.json());

app.use(Passport.initialize());



var JSONWebToken = require('jsonwebtoken');

var Crypto = require('crypto');

var generateToken = function(user) {
    var payload = {
        id : user.id,
        username : user.username
    };

    var secret = user.secret || Crypto.randomBytes(128).toString('base64');

    var token = JSONWebToken.sign(payload, secret);

    user.secret = secret;

    return token;
}


var generateTokenHandler = function(request, response) {
    var user = request.user;

    var token = generateToken(user);
    response.end(token);

}



app.post( '/login',
    Passport.authenticate('local', {session : false}),
    generateTokenHandler
);



var BearerStrategy = require('passport-http-bearer').Strategy;

var verifyToken = function(token, done) {
    var payload = JSONWebToken.decode(token);

    var user = users[payload.username];

    if(user == null ||
        user.id !== payload.id ||
        user.username !== payload.username) {
            return done(null, false)
    }

    JSONWebToken.verify(token, user.secret, function(error, decoded) {
        if(error || decoded == null) {
            return done(error, false);
        }
        return done(null, user);
    });

    
}

var bearerStrategy = new BearerStrategy( verifyToken);

Passport.use('bearer', bearerStrategy);


app.get('/userinfo',
        Passport.authenticate('bearer', {session : false}),
        function(request, response) {
            var user = request.user;
            response.send( {
                id : user.id,
                username : user.username            
            });
        });



app.listen(8080, function () {
    console.log("server started -8080")
})



//http://localhost:8080/userinfo

//Authorization
//Bearer <token>