import { Image } from './image.js';

//factory method pattern 
function createImage(name) {
    return new Image(name);
}

//factory method invocation 

const image = createImage('photo.jpeg')

console.log(image);