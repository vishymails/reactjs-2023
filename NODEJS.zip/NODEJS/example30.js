var fs = require('fs');
var zlib = require('zlib');

fs.createReadStream('example1.htm.gz')
    .pipe(zlib.createGunzip())
    .pipe(fs.createWriteStream('example11.htm'));

console.log("decompressed");
