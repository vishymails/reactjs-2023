var profiles = require('./profiles');

profiles = JSON.stringify(profiles).replace(/name/g, 'fullname');

profiles = JSON.parse(profiles);

profiles.felix.fullname = "Felix Robert Geisendorfer";


console.log(profiles.felix);

